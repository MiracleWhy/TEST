package com.uton.carsokApi.model;

import java.util.Date;

public class Acount {
    private Integer id;

    private Integer accountCode;

    private String account;

    private String accountPassword;

    private String nick;

    private String mobile;

    private Integer accountType;

    private String payPassword;

    private Short isRealNameAudit;

    private Short isMerchantAudit;

    private String realName;

    private String idcard;

    private String headPortraitPath;

    private String businessLicencePath;

    private String accountKey;

    private String merchantName;

    private Integer provinceId;

    private Integer cityId;

    private String merchantAddress;

    private String merchantDescr;

    private String merchantImagePath;

    private Date createTime;

    private Date updateTime;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getAccountCode() {
        return accountCode;
    }

    public void setAccountCode(Integer accountCode) {
        this.accountCode = accountCode;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account == null ? null : account.trim();
    }

    public String getAccountPassword() {
        return accountPassword;
    }

    public void setAccountPassword(String accountPassword) {
        this.accountPassword = accountPassword == null ? null : accountPassword.trim();
    }

    public String getNick() {
        return nick;
    }

    public void setNick(String nick) {
        this.nick = nick == null ? null : nick.trim();
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile == null ? null : mobile.trim();
    }

    public Integer getAccountType() {
        return accountType;
    }

    public void setAccountType(Integer accountType) {
        this.accountType = accountType;
    }

    public String getPayPassword() {
        return payPassword;
    }

    public void setPayPassword(String payPassword) {
        this.payPassword = payPassword == null ? null : payPassword.trim();
    }

    public Short getIsRealNameAudit() {
        return isRealNameAudit;
    }

    public void setIsRealNameAudit(Short isRealNameAudit) {
        this.isRealNameAudit = isRealNameAudit;
    }

    public Short getIsMerchantAudit() {
        return isMerchantAudit;
    }

    public void setIsMerchantAudit(Short isMerchantAudit) {
        this.isMerchantAudit = isMerchantAudit;
    }

    public String getRealName() {
        return realName;
    }

    public void setRealName(String realName) {
        this.realName = realName == null ? null : realName.trim();
    }

    public String getIdcard() {
        return idcard;
    }

    public void setIdcard(String idcard) {
        this.idcard = idcard == null ? null : idcard.trim();
    }

    public String getHeadPortraitPath() {
        return headPortraitPath;
    }

    public void setHeadPortraitPath(String headPortraitPath) {
        this.headPortraitPath = headPortraitPath == null ? null : headPortraitPath.trim();
    }

    public String getBusinessLicencePath() {
        return businessLicencePath;
    }

    public void setBusinessLicencePath(String businessLicencePath) {
        this.businessLicencePath = businessLicencePath == null ? null : businessLicencePath.trim();
    }

    public String getAccountKey() {
        return accountKey;
    }

    public void setAccountKey(String accountKey) {
        this.accountKey = accountKey == null ? null : accountKey.trim();
    }

    public String getMerchantName() {
        return merchantName;
    }

    public void setMerchantName(String merchantName) {
        this.merchantName = merchantName == null ? null : merchantName.trim();
    }

    public Integer getProvinceId() {
        return provinceId;
    }

    public void setProvinceId(Integer provinceId) {
        this.provinceId = provinceId;
    }

    public Integer getCityId() {
        return cityId;
    }

    public void setCityId(Integer cityId) {
        this.cityId = cityId;
    }

    public String getMerchantAddress() {
        return merchantAddress;
    }

    public void setMerchantAddress(String merchantAddress) {
        this.merchantAddress = merchantAddress == null ? null : merchantAddress.trim();
    }

    public String getMerchantDescr() {
        return merchantDescr;
    }

    public void setMerchantDescr(String merchantDescr) {
        this.merchantDescr = merchantDescr == null ? null : merchantDescr.trim();
    }

    public String getMerchantImagePath() {
        return merchantImagePath;
    }

    public void setMerchantImagePath(String merchantImagePath) {
        this.merchantImagePath = merchantImagePath == null ? null : merchantImagePath.trim();
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }
}