package com.uton.carsokApi.dao;

import com.uton.carsokApi.model.Acount;

public interface AcountMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(Acount record);

    int insertSelective(Acount record);

    Acount selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(Acount record);

    int updateByPrimaryKey(Acount record);
}